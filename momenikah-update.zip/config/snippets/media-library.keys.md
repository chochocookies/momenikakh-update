# Keys to change in config/media-library.php (after `php artisan vendor:publish --tag=medialibrary-config`)

| Key | Value | Why |
|---|---|---|
| `disk_name` | `env('MEDIA_DISK', 'media')` | the disk from `filesystems.php` |
| `max_file_size` | `1024 * 1024 * 12` | hard ceiling; real limits are enforced earlier by `ImageInspector` / `AudioInspector` |
| `queue_name` | `'media'` | run a worker with `--queue=media,default` so image work never blocks emails |
| `queue_conversions_by_default` | `env('QUEUE_CONVERSIONS_BY_DEFAULT', true)` | conversions run on the queue (MED-02) |
| `path_generator` | `App\Domain\Media\UuidPathGenerator::class` | unguessable `ab/uuid/` layout (MED-01) |
| `image_driver` | `env('IMAGE_DRIVER', 'gd')` | GD with WebP support is enough; Imagick also works. Check the key name for your installed version |
| `version_urls` | `false` | file names are unique, no `?v=` query needed (better CDN caching) |
| `default_loading_attribute_value` | `'lazy'` | |

Other keys keep their defaults. Check the config file of the version you installed: key names can differ between major versions.
