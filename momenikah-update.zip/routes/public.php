<?php

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Route;


Route::get('/', fn () => Blade::render('<x-layouts.public>Public Invitation Surface</x-layouts.public>'))->name('public.home');
