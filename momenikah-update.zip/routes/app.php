<?php

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Route;


Route::get('/', fn () => Blade::render('<x-layouts.app>Application Surface</x-layouts.app>'))->name('app.home');

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});
